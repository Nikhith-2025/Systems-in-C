#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct cpu cpus[NCPU];

struct proc proc[NPROC];

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  for(p = proc; p < &proc[NPROC]; p++) {
      initlock(&p->lock, "proc");
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;
  
  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;

  // Allocate a trapframe page.
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;
  
  // Initialize core scheduling fields
  acquire(&tickslock);
  p->creation_time = ticks;                     // Creation time for FCFS
  release(&tickslock);
  p->priority_level = 0;                        // Default priority level (neutral priority)
  p->process_weight = 1024;                     // Default weight (will be calculated later)
  p->virtual_runtime = 0;                       // Initialize virtual runtime
  p->allocated_slice = 0;                       // Will be computed per scheduling decision
  p->consumed_ticks = 0;                        // Reset tick counter
  
  // Initialize MLFQ fields
  p->queue_level = 0;      // Start in highest priority queue
  p->time_quantum_used = 0;
  p->time_quantum_limit = 1; // Queue 0 has 1 tick time slice
  p->queue_entry_time = ticks;

  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;
  if(p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if(pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
              (uint64)trampoline, PTE_R | PTE_X) < 0){
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
              (uint64)(p->trapframe), PTE_R | PTE_W) < 0){
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;
  
  p->cwd = namei("/");

  p->state = RUNNABLE;

  release(&p->lock);
}

// Shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if(n > 0){
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if(n < 0){
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
kfork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy user memory from parent to child.
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for(i = 0; i < NOFILE; i++)
    if(p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  release(&np->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  acquire(&np->lock);
  np->state = RUNNABLE;
  release(&np->lock);

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for(pp = proc; pp < &proc[NPROC]; pp++){
    if(pp->parent == p){
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
kexit(int status)
{
  struct proc *p = myproc();

  if(p == initproc)
    panic("init exiting");

  // Close all open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd]){
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);
  
  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
kwait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(pp = proc; pp < &proc[NPROC]; pp++){
      if(pp->parent == p){
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if(pp->state == ZOMBIE){
          // Found one.
          pid = pp->pid;
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
                                  sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || killed(p)){
      release(&wait_lock);
      return -1;
    }
    
    // Wait for a child to exit.
    sleep(p, &wait_lock);  //DOC: wait-sleep
  }
}

#if ACTIVE_SCHEDULER == SCHED_CFS
// Compute process weight from nice value using integer arithmetic
// Higher nice -> lower weight -> less CPU time
// Lower nice -> higher weight -> more CPU time
static uint64 calculate_weight_from_priority(int nice_value) {
  // Clamp nice value to valid range [-20, 19]
  if (nice_value < -20) nice_value = -20;
  if (nice_value > 19) nice_value = 19;
  
  // Base weight for nice=0
  uint64 base_weight = 1024;
  
  if (nice_value > 0) {
    // Positive nice: reduce weight (lower priority)
    // Use 4/5 ratio to approximate 1/1.25 
    for (int i = 0; i < nice_value; i++) {
      base_weight = (base_weight * 4 + 2) / 5; // +2 for rounding
      if (base_weight < 1) base_weight = 1;   // Ensure minimum weight
    }
  } else if (nice_value < 0) {
    // Negative nice: increase weight (higher priority)
    // Use 5/4 ratio to approximate 1.25
    for (int i = 0; i < -nice_value; i++) {
      base_weight = (base_weight * 5 + 2) / 4; // +2 for rounding
    }
  }
  
  return (base_weight < 1) ? 1 : base_weight;
}
#endif


// CFS tick update with detailed vruntime progression
void update_virtual_runtime_on_tick() {
  struct proc *current = myproc();
  if (current == 0) return;
  
  // Only update for CFS
  #ifdef CFS
  uint64 weight = current->process_weight > 0 ? current->process_weight : 1024;
  uint64 delta = (1024 * VRUNTIME_SCALE_FACTOR) / weight;
  
  uint64 old_vruntime = current->virtual_runtime;
  current->virtual_runtime += delta;
  
  if (current->virtual_runtime >= 5000 && (current->virtual_runtime - old_vruntime == delta)) {
    printf("PID %d virtual_runtime: %lu -> %lu (delta: %lu)\n", 
           current->pid, (unsigned long)old_vruntime, (unsigned long)current->virtual_runtime, (unsigned long)delta);
  }
  
  if (current->allocated_slice > 0) {
    current->consumed_ticks++;
    if (current->consumed_ticks >= current->allocated_slice) {
      yield();
    }
  }
  #endif
}

// Per-CPU process scheduler.
// Each CPU calls scheduler() after setting itself up.
// Scheduler never returns.  It loops, doing:
//  - choose a process to run.
//  - swtch to start running that process.
//  - eventually that process transfers control
//    via swtch back to the scheduler.
void
scheduler(void)
{
  struct proc *p;
  struct cpu *c = mycpu();

  c->proc = 0;
  for(;;){
    // The most recent process to run may have had interrupts
    // turned off; enable them to avoid a deadlock if all
    // processes are waiting. Then turn them back off
    // to avoid a possible race between an interrupt
    // and wfi.
    intr_on();
    intr_off();

    int found = 0;
    
#if ACTIVE_SCHEDULER == SCHED_FCFS
    // First Come First Serve: Non-preemptive, earliest creation time wins
    static int fcfs_first_run = 1;
    if (fcfs_first_run) {
      printf("\nFCFS (First Come First Serve) SCHEDULER\n");
      fcfs_first_run = 0;
    }
    
    struct proc *earliest_proc = 0;
    uint64 earliest_creation_time = 0;
    
    // Scan for runnable process with earliest creation time
    for (p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if (p->state == RUNNABLE) {
        if (earliest_proc == 0 || p->creation_time < earliest_creation_time) {
          if (earliest_proc != 0) {
            release(&earliest_proc->lock);
          }
          earliest_proc = p;
          earliest_creation_time = p->creation_time;
          // Keep lock for selected process
        } else {
          release(&p->lock);
        }
      } else {
        release(&p->lock);
      }
    }
    
    if (earliest_proc != 0) {
      // Debug output for FCFS scheduling decision (limited frequency)
      static int schedule_count = 0;
      if ((++schedule_count % 100) == 0) {
        printf("[FCFS] Running PID %d (creation_time: %lu) - non-preemptive\n", 
               earliest_proc->pid, (unsigned long)earliest_proc->creation_time);
      }
      
      // Run the earliest process (lock still held)
      earliest_proc->state = RUNNING;
      c->proc = earliest_proc;
      swtch(&c->context, &earliest_proc->context);
      c->proc = 0;
      found = 1;
      release(&earliest_proc->lock);
    }
    
#elif defined(MLFQ)
    // Multi-Level Feedback Queue Scheduler
    struct proc *selected = 0;
    
    // Check for starvation prevention every 48 ticks
    static uint64 last_boost_time = 0;
    acquire(&tickslock);
    uint64 current_ticks = ticks;
    release(&tickslock);
    
    if (current_ticks - last_boost_time >= 48) {
      // Boost all processes to queue 0
      for (p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->state == RUNNABLE || p->state == RUNNING) {
          p->queue_level = 0;
          p->time_quantum_used = 0;
          p->time_quantum_limit = 1;
          p->queue_entry_time = current_ticks;
        }
        release(&p->lock);
      }
      last_boost_time = current_ticks;
      printf("MLFQ: Boosted all processes to queue 0\n");
    }
    
    // Find process in highest priority non-empty queue
    for (int queue = 0; queue < 4; queue++) {
      for (p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->state == RUNNABLE && p->queue_level == queue) {
          if (selected == 0) {
            selected = p;
            break;
          }
        }
        release(&p->lock);
      }
      if (selected != 0) break;
    }
    if (selected != 0) {
      // Set time quantum based on queue level
      int time_slices[] = {1, 4, 8, 16};
      selected->time_quantum_limit = time_slices[selected->queue_level];
      
      printf("MLFQ: Running PID %d from queue %d (quantum: %d)\n", 
             selected->pid, selected->queue_level, selected->time_quantum_limit);
      
      selected->state = RUNNING;
      c->proc = selected;
      
      acquire(&tickslock);
      uint64 start_time = ticks;
      release(&tickslock);
      
      swtch(&c->context, &selected->context);
      
      acquire(&tickslock);
      uint64 elapsed = ticks - start_time;
      release(&tickslock);
      
      selected->time_quantum_used += elapsed;
      
      // Check if process used full time slice
      if (selected->time_quantum_used >= selected->time_quantum_limit) {
        // Move to next lower queue (unless already in queue 3)
        if (selected->queue_level < 3) {
          selected->queue_level++;
          printf("MLFQ: PID %d demoted to queue %d\n", selected->pid, selected->queue_level);
        }
        selected->time_quantum_used = 0;
        selected->queue_entry_time = ticks;
      }
      
      c->proc = 0;
      found = 1;
      release(&selected->lock);
    }
    
#elif ACTIVE_SCHEDULER == SCHED_CFS
    // Completely Fair Scheduler: Pick process with minimum vruntime
    static int cfs_first_run = 1;
    if (cfs_first_run) {
      printf("\nCFS (Completely Fair Scheduler)\n");
      cfs_first_run = 0;
    }
    
    struct proc *min_vruntime_proc = 0;
    uint64 minimum_vruntime = ~0ULL;
    int total_runnable = 0;
    
    // First scan: count runnable processes
    for (p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if (p->state == RUNNABLE) {
        total_runnable++;
      }
      release(&p->lock);
    }
    
    // Only proceed if there are runnable processes
    if (total_runnable > 0) {
      // Print scheduler tick header for every decision when multiple processes exist
      if (total_runnable > 1) {
        printf("[Scheduler Tick]\n");
        
        // Show all runnable processes with their vruntime
        for (p = proc; p < &proc[NPROC]; p++) {
          acquire(&p->lock);
          if (p->state == RUNNABLE) {
            printf("PID: %d | vRuntime: %lu\n", p->pid, (unsigned long)p->virtual_runtime);
          }
          release(&p->lock);
        }
      }
      
      // Second scan: select process with minimum vruntime
      for (p = proc; p < &proc[NPROC]; p++) {
        acquire(&p->lock);
        if (p->state == RUNNABLE) {
          if (min_vruntime_proc == 0 || p->virtual_runtime < minimum_vruntime) {
            if (min_vruntime_proc != 0) {
              release(&min_vruntime_proc->lock);
            }
            min_vruntime_proc = p;
            minimum_vruntime = p->virtual_runtime;
            // Keep lock for selected process
          } else {
            release(&p->lock);
          }
        } else {
          release(&p->lock);
        }
      }
      
      // Announce which process was selected (when multiple processes compete)
      if (min_vruntime_proc != 0 && total_runnable > 1) {
        printf("--> Scheduling PID %d (lowest vRuntime)\n\n", min_vruntime_proc->pid);
      }
      
      if (min_vruntime_proc != 0) {
        // Compute dynamic time slice based on system load
        int target_latency_ticks = 48;
        int computed_slice = target_latency_ticks / total_runnable;
        if (computed_slice < 3) computed_slice = 3; // Enforce minimum
        
        min_vruntime_proc->allocated_slice = computed_slice;
        min_vruntime_proc->consumed_ticks = 0; // Reset tick counter
        
        // Update weight based on priority level
        min_vruntime_proc->process_weight = calculate_weight_from_priority(min_vruntime_proc->priority_level);
        
        // Execute the selected process
        min_vruntime_proc->state = RUNNING;
        c->proc = min_vruntime_proc;
        
        swtch(&c->context, &min_vruntime_proc->context);
        
        c->proc = 0;
        found = 1;
        release(&min_vruntime_proc->lock);
      }
    }
    
#else
    // Default Round Robin Scheduler
    for(p = proc; p < &proc[NPROC]; p++) {
      acquire(&p->lock);
      if(p->state == RUNNABLE) {
        // Switch to chosen process.  It is the process's job
        // to release its lock and then reacquire it
        // before jumping back to us.
        p->state = RUNNING;
        c->proc = p;
        swtch(&c->context, &p->context);

        // Process is done running for now.
        // It should have changed its p->state before coming back.
        c->proc = 0;
        found = 1;
      }
      release(&p->lock);
    }
#endif
    
    if(found == 0) {
      // nothing to run; stop running on this core until an interrupt.
      asm volatile("wfi");
    }
  }
}

// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.
void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&p->lock))
    panic("sched p->lock");
  if(mycpu()->noff != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched RUNNING");
  if(intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void
yield(void)
{
  struct proc *p = myproc();
  acquire(&p->lock);
  p->state = RUNNABLE;
  sched();
  release(&p->lock);
}

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();

  // Still holding p->lock from scheduler.
  release(&p->lock);

  if (first) {
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);

    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    if (p->trapframe->a0 == -1) {
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
  uint64 satp = MAKE_SATP(p->pagetable);
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
  ((void (*)(uint64))trampoline_userret)(satp);
}

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  // Must acquire p->lock in order to
  // change p->state and then call sched.
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
  release(lk);

  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  release(&p->lock);
  acquire(lk);
}

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
        p->state = RUNNABLE;
      }
      release(&p->lock);
    }
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING){
        // Wake process from sleep().
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;
  
  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if(user_dst){
    return copyout(p->pagetable, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if(user_src){
    return copyin(p->pagetable, dst, src, len);
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [USED]      "used",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
  printf("PID\tSTATE\tNAME\t\tCTIME\tNICE\tVRUNTIME\tWEIGHT\n");
  printf("===\t=====\t====\t\t=====\t====\t========\t======\n");
  
  for(p = proc; p < &proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    
    printf("%d\t%s\t%s\t\t%ld\t%d\t%ld\t\t%ld\n", 
           p->pid, state, p->name, p->creation_time, p->priority_level, p->virtual_runtime, p->process_weight);
  }
  printf("\n");
}
